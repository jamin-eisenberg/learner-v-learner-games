import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import g4p_controls.*; 
import java.util.Scanner; 
import java.awt.Font; 
import java.util.Random; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class LearnerVLearnerGames extends PApplet {





Learner l1, l2;

boolean graphing;
int currStrat = 0;
//polish: auto-upgrade to integers > 0?, better graph display manipulation?, more precise error messages?, one weights box?, COMMENTS?
final int xMin = 25;
final int xMax = 620;
final int yMin = 785;
final int yMax = 440;

public void setup() {
  
  createGUI();
  customGUI();

  graphing = false;
}

public void draw() {
  background(230);

  stroke(0);

  line(10, 370, width - 10, 370);
  line(660, 10, 660, height - 10);
  line(xMin, yMax, xMin, yMin);
  line(xMin, yMin, xMax, yMin);

  if (graphing) {
    int p1Strats = l1.getCurrWeights().length;
    int player, playerStrat;

    if (currStrat < p1Strats) player = 1;
    else player = 2;

    if (currStrat < p1Strats) {
      playerStrat = currStrat + 1;
    } else {
      playerStrat = currStrat - p1Strats + 1;
    }

    strategyLabel.setText("Player " + player + "\nStrategy " + playerStrat);
    if (player == 1) graph(getPoints(playerStrat - 1, l1.getAllWeightsTotal()));
    else             graph(getPoints(playerStrat - 1, l2.getAllWeightsTotal()));
  }
}

public void graph(int[] points) { //x always increases by one, so 1 dimension
  stroke(0, 0, 255);
  int gamesPerLearner = l1.getGamesPerLearner();
  int x = 0, y;
  int prevX = 0, prevY = 0;
  int mappedX, mappedY;

  for (int i = 0; i < points.length; i++) {
    x++;
    y = points[i];
    mappedX = (int)map(x, 1, gamesPerLearner, xMin, xMax);
    mappedY = (int)map(y, 0, 100, yMin, yMax);
    if (i == 1)     line(xMin, mappedY, mappedX, mappedY);
    else if (i > 1) line(prevX, prevY, mappedX, mappedY);
    prevX = mappedX;
    prevY = mappedY;
  }
}

public void run() {
  int gamesPerLearner = Integer.valueOf(gamesPerSimText.getText());
  int learnersPerBatch = Integer.valueOf(numSimsText.getText());

  for (int i = 0; i < learnersPerBatch; i++) {
    for (int j = 0; j < gamesPerLearner; j++) {
      int l1Pick = l1.pick();
      int l2Pick = l2.pick();

      l1.resolvePayoff(l1Pick, l2Pick);
      l2.resolvePayoff(l2Pick, l1Pick);
    }

    l1.reset();
    l2.reset();
  }
}

public void setFinalResultsText() {
  String str = "Final results:\n(may not add to 100 because of rounding errors)\n(Player Strategy Result)\n";

  int[] points1, points2;

  for (int currStrat = 0; currStrat < l1.currWeights.length; currStrat++) {
    points1 = getPoints(currStrat, l1.allWeightsTotal);
    str += "1, " + (currStrat + 1) + ", " + points1[points1.length-1] + "%\n";
  }
  for (int currStrat = 0; currStrat < l2.currWeights.length; currStrat++) {
    points2 = getPoints(currStrat, l2.allWeightsTotal);
    str += "2, " + (currStrat + 1) + ", " + points2[points2.length-1] + "%\n";
  }

  finalResultLabel.setText(str);
}

public void makeLearners() {
  int gamesPerLearner = Integer.valueOf(gamesPerSimText.getText()) + 1;
  String gameStr = gameText.getText(); //get strings from textboxes in GUI
  String p1WeightsStr = p1WeightsText.getText();  
  String p2WeightsStr = p2WeightsText.getText();
  boolean asymmetric = gameStr.contains(",");
  double recencyIndex = recencySlider.getValueF();
  double errorRate = errorSlider.getValueF();
  double[] p1Weights = strToWeights(p1WeightsStr);
  double[] p2Weights = strToWeights(p2WeightsStr);

  if (p2WeightsStr.equals("") || p2WeightsStr.equals(" ")) {
    p2Weights = new double[p1Weights.length];
    for (int i = 0; i < p2Weights.length; i++) {
      p2Weights[i] = p1Weights[i];
    }
  }

  if (asymmetric) {
    String[] matrices = splitMatrix(gameStr);
    l1 = new Learner(strToMatrix(matrices[0]), p1Weights, recencyIndex, errorRate, gamesPerLearner, false);
    l2 = new Learner(strToMatrix(matrices[1]), p2Weights, recencyIndex, errorRate, gamesPerLearner, true);
  } else {
    double[][] gameMat = strToMatrix(gameStr);
    l1 = new Learner(gameMat, p1Weights, recencyIndex, errorRate, gamesPerLearner, false);
    l2 = new Learner(flipDiag(gameMat), p2Weights, recencyIndex, errorRate, gamesPerLearner, true);
  }
}

public double[][] flipDiag(double[][] mat) {
  double[][] newMat = new double[mat.length][mat[0].length];
  for (int i = 0; i < newMat.length; i++) {
    for (int j = 0; j < newMat[0].length; j++) {
      newMat[i][j] = mat[j][i];
    }
  }

  return newMat;
}

public double[] strToWeights(String weightsStr) {
  Scanner scanner = new Scanner(weightsStr);
  int weightsLength = 0;
  while (scanner.hasNext()) {
    scanner.next();
    weightsLength++;
  }

  double[] weights = new double[weightsLength];
  scanner = new Scanner(weightsStr);
  int pos = 0;
  while (scanner.hasNextDouble()) {
    weights[pos] = scanner.nextDouble();
    pos++;
  }

  return weights;
}

public String[] splitMatrix(String gameStr) {
  gameStr = gameStr.replace("\n", " \n ");
  Scanner scanner = new Scanner(gameStr).useDelimiter(" ");
  String[] result = {"", ""};

  while (scanner.hasNext()) {
    String token = scanner.next();
    if (token.contains("\n")) {
      result[0] += "\n";
      result[1] += "\n";
      continue;
    }
    try {
      String[] curr = token.split(",");
      result[0] += curr[0] + " ";
      result[1] += curr[1] + " ";
    }
    catch(ArrayIndexOutOfBoundsException e) {
    } //somehow spaces make their way in and it tries to split them by commas
  }

  return result;
}

public double[][] strToMatrix(String str) {
  int width = 0, height = 0;

  Scanner lineScanner = new Scanner(str);
  while (lineScanner.hasNextLine()) {
    String line = lineScanner.nextLine();
    width = line.split(" ").length;
    height++;
  }

  double[][] mat = new double[height][width];

  Scanner numScanner = new Scanner(str);

  int pos = 0;
  while (numScanner.hasNextInt()) {
    mat[pos / width][pos % width] = numScanner.nextInt();
    pos++;
  }

  return mat;
}

public void printMatrix(int[][] mat) {
  for (int i = 0; i < mat.length; i++) {
    for (int j = 0; j < mat[0].length; j++) {
      print(mat[i][j] + " ");
    }
    println();
  }
}

public int[] getPoints(int playerStrat, double[][] allWeightsTotal) {
  int[] points = new int[allWeightsTotal.length];
  double[] currWeights = new double[allWeightsTotal[0].length];

  for (int k = 0; k < points.length; k++) {
    for (double e : currWeights) e = 0;

    for (int i = 0; i < currWeights.length; i++) {
      for (int j = 0; j < k; j++) {
        currWeights[i] += allWeightsTotal[j][i];
      }
    }
    points[k] = (int)(100 * currWeights[playerStrat] / total(currWeights));
  }

  return points;
}

public double total(double[] arr) {
  double total = 0;
  for (int i = 0; i < arr.length; i++) {
    total += arr[i];
  }
  return total;
}

public void setMatrixRepText() {
  int[][] matrix = new int[l1.payoffs.length][l1.payoffs[0].length];
  String str = "Matrix Play Representation:\n\n\n";

  int[] p1Percents = new int[l1.currWeights.length];
  int[] p2Percents = new int[l2.currWeights.length];
  int[] points1, points2;

  for (int currStrat = 0; currStrat < p1Percents.length; currStrat++) {
    points1 = getPoints(currStrat, l1.allWeightsTotal);
    p1Percents[currStrat] = points1[points1.length-1];
  }
  for (int currStrat = 0; currStrat < p2Percents.length; currStrat++) {
    points2 = getPoints(currStrat, l2.allWeightsTotal);
    p2Percents[currStrat] = points2[points2.length-1];
  }

  for (int i = 0; i < matrix.length; i++) {
    for (int j = 0; j < matrix[0].length; j++) {
      matrix[i][j] = p1Percents[i] * p2Percents[j] / 100;
      str += String.format("%-4d", matrix[i][j]);
    }
    str += "\n";
  }

  matrixRepLabel.setText(str);
}

// Use this method to add additional statements
// to customise the GUI controls
public void customGUI() {
  Font font = new Font("SanSerif", Font.PLAIN, 18);

  gameLabel.setFont(font);
  gameText.setFont(font);
  errorLabel.setFont(font);
  weightLabel.setFont(font);
  p1WeightsText.setFont(font);
  runGameButton.setFont(font);
  p2WeightsText.setFont(font);
  gamesPerLearnerLabel.setFont(font);
  learnersPerBatchLabel.setFont(font);
  yMaxLabel.setFont(font);
  yMinLabel.setFont(font);
  xMinLabel.setFont(font);
  xMaxLabel.setFont(font);
  nextLineButton.setFont(font);
  inputErrorLabel.setFont(font);
  strategyLabel.setFont(font);
  prevLineButton.setFont(font);
  //yLabel.setFont(font);
  //xLabel.setFont(font);
  recencyLabel.setFont(font);
  finalResultLabel.setFont(font);
  numSimsText.setFont(font);
  gamesPerSimText.setFont(font);
  matrixRepLabel.setFont(new Font("mono", Font.PLAIN, 18));
}


public class Learner {
  private double[][] payoffs;
  private double[][] allWeights;
  private double[] currWeights;
  private double recencyIndex;
  private double errorRate;
  private int allWeightsCount;
  private boolean isPlayer2;
  private Random rand;

  private double[][] allWeightsTotal;

  //used for reset only:
  private double[] initWeights;
  private int gamesPerLearner;

  public Learner(double[][] payoffs, double[] initWeights, double recencyIndex, double errorRate, int gamesPerLearner, boolean isPlayer2) {
    this.payoffs = payoffs;
    this.currWeights = new double[initWeights.length];
    for (int i = 0; i < initWeights.length; i++) {
      currWeights[i] = initWeights[i];
    }
    this.recencyIndex = recencyIndex;
    this.errorRate = errorRate;
    allWeights = new double[gamesPerLearner][initWeights.length];
    for (int i = 0; i < initWeights.length; i++) allWeights[0][i] = initWeights[i];
    allWeightsCount = 1;
    this.isPlayer2 = isPlayer2;
    rand = new Random();

    this.allWeightsTotal = new double[allWeights.length][allWeights[0].length];
    for (int i = 0; i < allWeightsTotal.length; i++) {
      for (int j = 0; j < allWeightsTotal[0].length; j++) {
        allWeightsTotal[i][j] = 0;
      }
    }

    this.initWeights = initWeights;
    this.gamesPerLearner = gamesPerLearner;
  }

  public double[] getCurrWeights() { 
    return currWeights;
  }

  public int getGamesPerLearner() { 
    return gamesPerLearner;
  }

  public double[][] getPayoffs() { 
    return payoffs;
  }

  public double[][] getAllWeights() { 
    return allWeights;
  }

  public boolean isPlayer2() { 
    return isPlayer2;
  }

  public double[][] getAllWeightsTotal() {
    return allWeightsTotal;
  }

  private void printWeights() {
    for (double i : currWeights) print(i + " ");
    println();
  }

  public int pick() {
    double randNum = rand.nextInt(102);

    sumWeights();

    if (randNum < errorRate * 100 + 1) {
      return rand.nextInt(currWeights.length);
    }

    double total = 0;
    for (int i = 0; i < currWeights.length; i++) {
      total += currWeights[i];
    }

    randNum = rand.nextDouble() * total;
    for (int i = 0; i < currWeights.length; i++) {
      randNum -= currWeights[i];
      if (randNum < 0) {
        return i;
      }
    }

    return -1;
  }

  public void resolvePayoff(int pick, int opponentPick) {
    double payoff;
    if (isPlayer2) payoff = payoffs[opponentPick][pick];
    else           payoff = payoffs[pick][opponentPick];

    for (int i = 0; i < currWeights.length; i++) {
      allWeights[allWeightsCount - 1][i] = 0;
    }

    allWeights[allWeightsCount - 1][pick] = payoff;
    allWeightsCount++;
  }

  private void sumWeights() {
    for (int i = 0; i < currWeights.length; i++) {
      for (int j = 0; j < allWeights.length; j++) {
        allWeights[j][i] *= recencyIndex;
        currWeights[i] += allWeights[j][i];
      }
    }
  }

  public void reset() {
    //add allWeights to allWeightsTotal
    for (int i = 0; i < allWeightsTotal.length; i++) {
      for (int j = 0; j < allWeightsTotal[0].length; j++) {
        allWeightsTotal[i][j] += allWeights[i][j];
      }
    }

    this.currWeights = new double[initWeights.length];
    for (int i = 0; i < initWeights.length; i++) {
      currWeights[i] = initWeights[i];
    }
    allWeights = new double[gamesPerLearner][initWeights.length];
    for (int i = 0; i < initWeights.length; i++) allWeights[0][i] = initWeights[i];
    allWeightsCount = 1;
    rand = new Random();
  }
}
/* =========================================================
 * ====                   WARNING                        ===
 * =========================================================
 * The code in this tab has been generated from the GUI form
 * designer and care should be taken when editing this file.
 * Only add/edit code inside the event handlers i.e. only
 * use lines between the matching comment tags. e.g.

 void myBtnEvents(GButton button) { //_CODE_:button1:12356:
     // It is safe to enter your event code here  
 } //_CODE_:button1:12356:
 
 * Do not rename this tab!
 * =========================================================
 */

public void gameTextChange(GTextArea source, GEvent event) { //_CODE_:gameText:763000:
  println("gameText - GTextArea >> GEvent." + event + " @ " + millis());
} //_CODE_:gameText:763000:

public void recencySliderChange(GSlider source, GEvent event) { //_CODE_:recencySlider:337396:
  println("slider1 - GSlider >> GEvent." + event + " @ " + millis());
} //_CODE_:recencySlider:337396:

public void errorSliderChange(GSlider source, GEvent event) { //_CODE_:errorSlider:951737:
  println("errorSlider - GSlider >> GEvent." + event + " @ " + millis());
} //_CODE_:errorSlider:951737:

public void runGameEvent(GButton source, GEvent event) { //_CODE_:runGameButton:961154:
  println("button1 - GButton >> GEvent." + event + " @ " + millis());
  try{
    currStrat = 0;
    makeLearners();
    run();
    setFinalResultsText();
    setMatrixRepText();
    xMaxLabel.setText(gamesPerSimText.getText());
    graphing = true;
    inputErrorLabel.setText("");
  }
  catch(Exception e){
    e.printStackTrace();
    inputErrorLabel.setText("INPUT ERROR. PLEASE FIX AND TRY AGAIN.");
  }
} //_CODE_:runGameButton:961154:

public void p2WeightsTextChange(GTextField source, GEvent event) { //_CODE_:p2WeightsText:447035:
  println("p2WeightsText - GTextField >> GEvent." + event + " @ " + millis());
} //_CODE_:p2WeightsText:447035:

public void nextLineButtonClick(GButton source, GEvent event) { //_CODE_:nextLineButton:728716:
  println("nextLineButton - GButton >> GEvent." + event + " @ " + millis());
  if(currStrat < l1.getCurrWeights().length + l2.getCurrWeights().length - 1) currStrat++;
} //_CODE_:nextLineButton:728716:

public void prevLineButtonClick(GButton source, GEvent event) { //_CODE_:prevLineButton:470163:
  println("prevLineButton - GButton >> GEvent." + event + " @ " + millis());
  if(currStrat > 0) currStrat--;
} //_CODE_:prevLineButton:470163:

public void p1WeightsTextChange(GTextField source, GEvent event) { //_CODE_:p1WeightsText:557522:
  println("p1WeightsText - GTextField >> GEvent." + event + " @ " + millis());
} //_CODE_:p1WeightsText:557522:

public void gamesPerSimChange(GTextField source, GEvent event) { //_CODE_:gamesPerSimText:338762:
  println("textfield1 - GTextField >> GEvent." + event + " @ " + millis());
} //_CODE_:gamesPerSimText:338762:

public void numSimsChange(GTextField source, GEvent event) { //_CODE_:numSimsText:252101:
  println("textfield2 - GTextField >> GEvent." + event + " @ " + millis());
} //_CODE_:numSimsText:252101:



// Create all the GUI controls. 
// autogenerated do not edit
public void createGUI(){
  G4P.messagesEnabled(false);
  G4P.setGlobalColorScheme(GCScheme.BLUE_SCHEME);
  G4P.setMouseOverEnabled(false);
  surface.setTitle("Learner vs Learner Game Simulation");
  gameLabel = new GLabel(this, 0, 0, 260, 120);
  gameLabel.setTextAlign(GAlign.LEFT, GAlign.TOP);
  gameLabel.setText("Enter the game matrix below, with space separated values, and commas between player payoffs if asymmetric (integers >= 0):");
  gameLabel.setOpaque(false);
  gameText = new GTextArea(this, 0, 120, 260, 210, G4P.SCROLLBARS_BOTH | G4P.SCROLLBARS_AUTOHIDE);
  gameText.setPromptText("0,1 3,3 6,4 3,2\n1,2 4,4 1,1 2,1\n0,0 3,6 5,2 1,1");
  gameText.setOpaque(true);
  gameText.addEventHandler(this, "gameTextChange");
  recencyLabel = new GLabel(this, 260, 0, 130, 30);
  recencyLabel.setTextAlign(GAlign.CENTER, GAlign.CENTER);
  recencyLabel.setText("Recency Index:");
  recencyLabel.setOpaque(false);
  recencySlider = new GSlider(this, 270, 30, 100, 60, 10.0f);
  recencySlider.setShowValue(true);
  recencySlider.setLimits(0.95f, 0.5f, 1.0f);
  recencySlider.setNumberFormat(G4P.DECIMAL, 2);
  recencySlider.setOpaque(false);
  recencySlider.addEventHandler(this, "recencySliderChange");
  errorLabel = new GLabel(this, 390, 0, 100, 30);
  errorLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  errorLabel.setText("Error Rate:");
  errorLabel.setOpaque(false);
  errorSlider = new GSlider(this, 390, 30, 100, 60, 10.0f);
  errorSlider.setShowValue(true);
  errorSlider.setLimits(0.05f, 0.0f, 0.5f);
  errorSlider.setNumberFormat(G4P.DECIMAL, 2);
  errorSlider.setOpaque(false);
  errorSlider.addEventHandler(this, "errorSliderChange");
  weightLabel = new GLabel(this, 260, 90, 230, 160);
  weightLabel.setTextAlign(GAlign.LEFT, GAlign.TOP);
  weightLabel.setText("Enter space separated weights that should initially be gven to each strategy, in the same order, integers >= 0. If applicable, write player two's weights in the second box:");
  weightLabel.setOpaque(false);
  runGameButton = new GButton(this, 0, 330, 650, 30);
  runGameButton.setText("RUN GAME");
  runGameButton.setTextBold();
  runGameButton.setTextItalic();
  runGameButton.setLocalColorScheme(GCScheme.RED_SCHEME);
  runGameButton.addEventHandler(this, "runGameEvent");
  p2WeightsText = new GTextField(this, 260, 290, 230, 40, G4P.SCROLLBARS_HORIZONTAL_ONLY | G4P.SCROLLBARS_AUTOHIDE);
  p2WeightsText.setPromptText("20 4 5 10");
  p2WeightsText.setOpaque(true);
  p2WeightsText.addEventHandler(this, "p2WeightsTextChange");
  gamesPerLearnerLabel = new GLabel(this, 510, 0, 140, 60);
  gamesPerLearnerLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  gamesPerLearnerLabel.setText("Games per simulation:");
  gamesPerLearnerLabel.setOpaque(false);
  learnersPerBatchLabel = new GLabel(this, 510, 100, 140, 60);
  learnersPerBatchLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  learnersPerBatchLabel.setText("# of simulations:");
  learnersPerBatchLabel.setOpaque(false);
  yMaxLabel = new GLabel(this, 0, 430, 20, 20);
  yMaxLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  yMaxLabel.setText("1");
  yMaxLabel.setOpaque(false);
  yMinLabel = new GLabel(this, 0, 770, 20, 20);
  yMinLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  yMinLabel.setText("0");
  yMinLabel.setOpaque(false);
  xMinLabel = new GLabel(this, 20, 790, 20, 20);
  xMinLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  xMinLabel.setText("0");
  xMinLabel.setOpaque(false);
  xMaxLabel = new GLabel(this, 590, 790, 80, 20);
  xMaxLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  xMaxLabel.setText("0");
  xMaxLabel.setOpaque(false);
  nextLineButton = new GButton(this, 340, 380, 310, 30);
  nextLineButton.setText("NEXT STRATEGY");
  nextLineButton.setTextBold();
  nextLineButton.setTextItalic();
  nextLineButton.addEventHandler(this, "nextLineButtonClick");
  inputErrorLabel = new GLabel(this, 490, 200, 160, 130);
  inputErrorLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  inputErrorLabel.setLocalColorScheme(GCScheme.RED_SCHEME);
  inputErrorLabel.setOpaque(false);
  strategyLabel = new GLabel(this, 560, 410, 90, 60);
  strategyLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  strategyLabel.setText("Player 0 Strategy 0");
  strategyLabel.setOpaque(false);
  prevLineButton = new GButton(this, 0, 380, 310, 30);
  prevLineButton.setText("PREVIOUS STRATEGY");
  prevLineButton.setTextBold();
  prevLineButton.setTextItalic();
  prevLineButton.addEventHandler(this, "prevLineButtonClick");
  yLabel = new GLabel(this, 0, 480, 20, 230);
  yLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  yLabel.setText("P  R  O  B  A  B  I  L  I  T  Y");
  yLabel.setTextItalic();
  yLabel.setOpaque(false);
  xLabel = new GLabel(this, 190, 790, 240, 20);
  xLabel.setTextAlign(GAlign.CENTER, GAlign.MIDDLE);
  xLabel.setText("GAME #");
  xLabel.setTextItalic();
  xLabel.setOpaque(false);
  p1WeightsText = new GTextField(this, 260, 250, 230, 40, G4P.SCROLLBARS_HORIZONTAL_ONLY | G4P.SCROLLBARS_AUTOHIDE);
  p1WeightsText.setPromptText("3 6 4");
  p1WeightsText.setOpaque(true);
  p1WeightsText.addEventHandler(this, "p1WeightsTextChange");
  finalResultLabel = new GLabel(this, 670, 10, 260, 350);
  finalResultLabel.setTextAlign(GAlign.LEFT, GAlign.TOP);
  finalResultLabel.setOpaque(false);
  gamesPerSimText = new GTextField(this, 510, 60, 140, 40, G4P.SCROLLBARS_HORIZONTAL_ONLY | G4P.SCROLLBARS_AUTOHIDE);
  gamesPerSimText.setOpaque(true);
  gamesPerSimText.addEventHandler(this, "gamesPerSimChange");
  numSimsText = new GTextField(this, 510, 160, 140, 40, G4P.SCROLLBARS_HORIZONTAL_ONLY | G4P.SCROLLBARS_AUTOHIDE);
  numSimsText.setOpaque(true);
  numSimsText.addEventHandler(this, "numSimsChange");
  matrixRepLabel = new GLabel(this, 670, 380, 260, 410);
  matrixRepLabel.setTextAlign(GAlign.LEFT, GAlign.TOP);
  matrixRepLabel.setOpaque(false);
  label1 = new GLabel(this, 670, 790, 260, 20);
  label1.setTextAlign(GAlign.RIGHT, GAlign.MIDDLE);
  label1.setText("Created by Jamin Eisenberg");
  label1.setOpaque(false);
}

// Variable declarations 
// autogenerated do not edit
GLabel gameLabel; 
GTextArea gameText; 
GLabel recencyLabel; 
GSlider recencySlider; 
GLabel errorLabel; 
GSlider errorSlider; 
GLabel weightLabel; 
GButton runGameButton; 
GTextField p2WeightsText; 
GLabel gamesPerLearnerLabel; 
GLabel learnersPerBatchLabel; 
GLabel yMaxLabel; 
GLabel yMinLabel; 
GLabel xMinLabel; 
GLabel xMaxLabel; 
GButton nextLineButton; 
GLabel inputErrorLabel; 
GLabel strategyLabel; 
GButton prevLineButton; 
GLabel yLabel; 
GLabel xLabel; 
GTextField p1WeightsText; 
GLabel finalResultLabel; 
GTextField gamesPerSimText; 
GTextField numSimsText; 
GLabel matrixRepLabel; 
GLabel label1; 
  public void settings() {  size(930, 810, JAVA2D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "LearnerVLearnerGames" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
